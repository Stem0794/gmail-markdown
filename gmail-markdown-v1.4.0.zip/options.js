var DEFAULTS = {
  convertOnPaste: false,
  autoFormat: true,
  gfm: true,
  theme: 'default',
  shortcut: 'Ctrl+Shift+M',
  codeShortcut: 'Ctrl+E',
  disableDefault: false
};

var VALID_MODIFIERS = ['ctrl', 'shift', 'alt', 'meta', 'cmd'];

function isValidShortcut(str) {
  if (!str) return false;
  var parts = str.toLowerCase().split('+').map(function (s) { return s.trim(); });
  if (parts.length < 2) return false;
  var key = parts.pop();
  if (!key || key.length === 0) return false;
  return parts.every(function (p) { return VALID_MODIFIERS.indexOf(p) !== -1; });
}

function saveOptions() {
  var shortcutInput = document.getElementById('shortcut').value.trim();
  if (shortcutInput && !isValidShortcut(shortcutInput)) {
    var status = document.getElementById('status');
    status.textContent = 'Invalid shortcut format. Use e.g. Ctrl+Shift+M';
    status.style.color = '#c00';
    setTimeout(function () { status.textContent = ''; status.style.color = ''; }, 3000);
    return;
  }

  var codeShortcutInput = document.getElementById('codeShortcut').value.trim();
  if (codeShortcutInput && !isValidShortcut(codeShortcutInput)) {
    var status = document.getElementById('status');
    status.textContent = 'Invalid code shortcut format. Use e.g. Ctrl+E or Cmd+E';
    status.style.color = '#c00';
    setTimeout(function () { status.textContent = ''; status.style.color = ''; }, 3000);
    return;
  }

  var opts = {
    convertOnPaste: document.getElementById('convertOnPaste').checked,
    autoFormat: document.getElementById('autoFormat').checked,
    gfm: document.getElementById('gfm').checked,
    theme: document.getElementById('theme').value,
    shortcut: shortcutInput || DEFAULTS.shortcut,
    codeShortcut: codeShortcutInput || DEFAULTS.codeShortcut,
    disableDefault: document.getElementById('disableDefault').checked
  };

  chrome.storage.sync.set(opts, function () {
    var status = document.getElementById('status');
    status.textContent = 'Options saved';
    status.style.color = '';
    setTimeout(function () { status.textContent = ''; }, 1500);

    if (chrome.commands && chrome.commands.update) {
      chrome.commands.update({ name: 'convert_markdown', shortcut: opts.shortcut }, function () {
        if (chrome.runtime.lastError) {
          console.warn('Failed to update command shortcut', chrome.runtime.lastError);
        }
      });
    }
  });
}

function restoreOptions() {
  chrome.storage.sync.get(DEFAULTS, function (items) {
    document.getElementById('convertOnPaste').checked = items.convertOnPaste;
    document.getElementById('autoFormat').checked = items.autoFormat;
    document.getElementById('gfm').checked = items.gfm;
    document.getElementById('theme').value = items.theme;
    document.getElementById('shortcut').value = items.shortcut;
    document.getElementById('codeShortcut').value = items.codeShortcut;
    document.getElementById('disableDefault').checked = items.disableDefault;
  });
}

document.getElementById('save').addEventListener('click', saveOptions);
document.addEventListener('DOMContentLoaded', restoreOptions);
